public class Hello {
	public static void main(String[] args) { //static void Main()
		System.out.println("Hello"); //Console.WriteLine("Hello");
	}
}
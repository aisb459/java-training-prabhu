package com.herbalife.springbootlab07kafkamongo.model;

public record Movie(String title, int year, boolean error) {
}

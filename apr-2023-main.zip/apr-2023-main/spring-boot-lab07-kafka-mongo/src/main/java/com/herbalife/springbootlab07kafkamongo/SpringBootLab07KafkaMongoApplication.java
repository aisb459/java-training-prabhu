package com.herbalife.springbootlab07kafkamongo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootLab07KafkaMongoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootLab07KafkaMongoApplication.class, args);
    }

}

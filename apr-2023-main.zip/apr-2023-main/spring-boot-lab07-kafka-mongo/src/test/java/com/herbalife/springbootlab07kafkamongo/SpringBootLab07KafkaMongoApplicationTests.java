package com.herbalife.springbootlab07kafkamongo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootLab07KafkaMongoApplicationTests {

    @Test
    void contextLoads() {
    }

}

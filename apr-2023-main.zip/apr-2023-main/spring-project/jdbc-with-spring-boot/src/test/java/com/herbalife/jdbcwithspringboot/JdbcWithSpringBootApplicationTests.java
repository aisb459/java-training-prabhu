package com.herbalife.jdbcwithspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JdbcWithSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}

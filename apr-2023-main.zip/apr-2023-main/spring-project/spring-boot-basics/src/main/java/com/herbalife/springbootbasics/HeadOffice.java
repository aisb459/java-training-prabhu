package com.herbalife.springbootbasics;

import org.springframework.stereotype.Component;

@Component
public class HeadOffice {
}

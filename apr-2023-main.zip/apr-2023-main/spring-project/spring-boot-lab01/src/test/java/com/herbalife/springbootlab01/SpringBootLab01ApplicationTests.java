package com.herbalife.springbootlab01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootLab01ApplicationTests {

    @Test
    void contextLoads() {
    }

}

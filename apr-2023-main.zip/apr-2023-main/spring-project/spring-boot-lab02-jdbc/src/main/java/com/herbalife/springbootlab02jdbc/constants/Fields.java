package com.herbalife.springbootlab02jdbc.constants;

public interface Fields {

    String TOPIC_ID = "id";
    String TOPIC_TITLE = "title";
    String TOPIC_DURATION = "duration";
}

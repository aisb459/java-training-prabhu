package com.herbalife.springbootlab02jdbc.model;

public record TopicRecord(int id, String title, int duration) {
}

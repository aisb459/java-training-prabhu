package com.herbalife.springbootlab02jdbc.constants;

public interface Messages {
    String TOPIC_WITH_TITLE_CREATED = "Topic with title: {} created";
    String TOPIC_WITH_TITLE_DELETED = "Topic with title: {} deleted";
}

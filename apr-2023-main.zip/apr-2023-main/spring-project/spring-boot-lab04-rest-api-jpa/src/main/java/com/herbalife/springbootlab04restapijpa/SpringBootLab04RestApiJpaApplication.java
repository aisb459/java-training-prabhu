package com.herbalife.springbootlab04restapijpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootLab04RestApiJpaApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootLab04RestApiJpaApplication.class, args);
    }

}

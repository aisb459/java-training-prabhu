package com.herbalife.springbootlab04restapijpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootLab04RestApiJpaApplicationTests {

    @Test
    void contextLoads() {
    }

}

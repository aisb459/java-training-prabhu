package com.example.springbootmoreonrestapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMoreOnRestApiApplicationTests {

    @Test
    void contextLoads() {
    }

}

package com.example.springbootmoreonrestapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMoreOnRestApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootMoreOnRestApiApplication.class, args);
    }

}

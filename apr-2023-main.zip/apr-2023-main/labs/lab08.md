* Build a User name, Password Validator with the following rules
* Given a user name, validate if it's blank and not null and empty and length should  be between 6 and 12
* Given a Password, validate if it's blank and not null and empty and length should be between 8 and 14 and with atleast one Uppercase character and atleast one number

* Use __and()__, __or()__ functions if neccessary


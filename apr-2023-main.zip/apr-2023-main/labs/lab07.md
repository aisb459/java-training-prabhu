* Replace the custom Functional interface in lab06 with a built-in functional interface from **java.util.function** package

``` java

@FunctionalInterface
interface Calc {
    int compute(int a, int b);
}
```

* Create the following structure in **com.herbalife.labs.lab03** package

* __Person__ has name and a array of cities visited
* __City__ has a name, and a country
* Every City belongs to a __Country__
* __Country__ has a name and capital and population

* __Person__ has another Person as a friend
* Define the classes each in a __separate file__.

* Create __Lab03.java__ with a main method. Create the objects with the following data using the classes you have defined.



```
Sam
Pune, India - New Delhi, 1.4 billion
New York City, USA - Washington DC, 400 million
Sam's friend is Ram

Ram has not visited any city yet
Ram's friend is Sam
```
package com.herbalife.lab08producerapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab08ProducerAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(Lab08ProducerAppApplication.class, args);
    }

}

package com.herbalife.lab08producerapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab08ProducerAppApplicationTests {

    @Test
    void contextLoads() {
    }

}

package com.example.miscapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiscAppApplicationTests {

	@Test
	void contextLoads() {
	}

}

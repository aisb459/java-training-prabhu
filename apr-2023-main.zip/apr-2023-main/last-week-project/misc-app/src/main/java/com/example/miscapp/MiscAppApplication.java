package com.example.miscapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiscAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MiscAppApplication.class, args);
	}

}

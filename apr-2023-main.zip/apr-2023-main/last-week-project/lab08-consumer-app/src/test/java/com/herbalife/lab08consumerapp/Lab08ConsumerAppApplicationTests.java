package com.herbalife.lab08consumerapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab08ConsumerAppApplicationTests {

    @Test
    void contextLoads() {
    }

}

package com.herbalife.lab08consumerapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab08ConsumerAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(Lab08ConsumerAppApplication.class, args);
    }

}

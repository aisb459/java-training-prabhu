package com.herbalife.kafkacloudstreamconsumerapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaCloudStreamConsumerAppApplicationTests {

    @Test
    void contextLoads() {
    }

}

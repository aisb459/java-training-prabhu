package com.herbalife.kafkacloudstreamconsumerapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaCloudStreamConsumerAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(KafkaCloudStreamConsumerAppApplication.class, args);
    }

}

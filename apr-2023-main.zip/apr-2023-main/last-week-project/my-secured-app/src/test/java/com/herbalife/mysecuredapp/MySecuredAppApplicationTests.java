package com.herbalife.mysecuredapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MySecuredAppApplicationTests {

    @Test
    void contextLoads() {
    }

}

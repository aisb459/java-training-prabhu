package com.herbalife.moreontransactions.service;

public class SillyException extends RuntimeException {
}

package com.herbalife.moreontransactions;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MoreOnTransactionsApplication {

    public static void main(String[] args) {
        SpringApplication.run(MoreOnTransactionsApplication.class, args);
    }

}

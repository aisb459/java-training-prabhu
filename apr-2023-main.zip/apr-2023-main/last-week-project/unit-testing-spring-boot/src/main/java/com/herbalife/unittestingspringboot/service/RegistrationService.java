package com.herbalife.unittestingspringboot.service;

import org.springframework.stereotype.Service;

@Service
public class RegistrationService {
    public boolean register(String email) {
        //SAVE TO DB
        return false;
    }
}

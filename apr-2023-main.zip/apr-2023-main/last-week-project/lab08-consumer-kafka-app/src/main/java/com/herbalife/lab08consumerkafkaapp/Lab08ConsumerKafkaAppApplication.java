package com.herbalife.lab08consumerkafkaapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab08ConsumerKafkaAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(Lab08ConsumerKafkaAppApplication.class, args);
    }

}

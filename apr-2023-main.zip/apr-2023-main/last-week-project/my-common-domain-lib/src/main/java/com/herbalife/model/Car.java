package com.herbalife.model;

public class Car {
}

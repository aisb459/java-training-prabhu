package com.ibm.thursday;

public class Hello {
}

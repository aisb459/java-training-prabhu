package com.herbalife.examples.one;

public class Vehicle {
    protected String chassisNo;

    protected String getChassisNo() {
        return this.chassisNo;
    }
}

package com.herbalife.examples.one;

public class Greetings {
    //Greetings() {}
    String message; //Package-friendly
    public String message2;
}

class Sample {}

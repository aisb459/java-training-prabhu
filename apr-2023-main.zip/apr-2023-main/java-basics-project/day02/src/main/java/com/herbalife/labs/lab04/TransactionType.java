package com.herbalife.labs.lab04;

public enum TransactionType {
    CREDIT,
    DEBIT,
    DEBIT_WITHDRAWAL_FEE
}

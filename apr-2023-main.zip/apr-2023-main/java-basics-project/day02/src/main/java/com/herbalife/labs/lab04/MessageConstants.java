package com.herbalife.labs.lab04;

public interface MessageConstants {
    String INSUFFICIENT_BALANCE = "Insufficient balance";
    String WITHDRAW_LIMIT_EXCEEDED = "Withdraw limit exceeded";
}

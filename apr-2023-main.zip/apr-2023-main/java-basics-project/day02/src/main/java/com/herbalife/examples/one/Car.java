package com.herbalife.examples.one;

public class Car extends Vehicle {
    public Car(String chassisNo) {
        this.chassisNo = chassisNo;
    }
}

package com.herbalife.examples;

public class Office {
}

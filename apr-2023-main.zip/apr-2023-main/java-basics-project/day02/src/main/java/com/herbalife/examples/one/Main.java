package com.herbalife.examples.one;

public class Main {
    public static void main(String[] args) {
        Car bmw = new Car("e123124");
        System.out.println(bmw.getChassisNo());
    }
}

package com.herbalife;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.context.RequestScoped;
import jakarta.enterprise.context.SessionScoped;


@ApplicationScoped
//@RequestScoped
//@SessionScoped
//@Scope("prototype") @Scope("session") in SB
public class CalculatorService {
}

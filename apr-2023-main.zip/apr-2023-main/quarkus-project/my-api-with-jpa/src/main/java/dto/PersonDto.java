package dto;

public record PersonDto(String firstName, String lastName, int age) {
}

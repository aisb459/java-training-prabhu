package com.herbalife.wordconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WordConsumerApplicationTests {

    @Test
    void contextLoads() {
    }

}

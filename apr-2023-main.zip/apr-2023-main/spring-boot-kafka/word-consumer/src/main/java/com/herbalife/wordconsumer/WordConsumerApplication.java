package com.herbalife.wordconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WordConsumerApplication {

    public static void main(String[] args) {
        SpringApplication.run(WordConsumerApplication.class, args);
    }

}

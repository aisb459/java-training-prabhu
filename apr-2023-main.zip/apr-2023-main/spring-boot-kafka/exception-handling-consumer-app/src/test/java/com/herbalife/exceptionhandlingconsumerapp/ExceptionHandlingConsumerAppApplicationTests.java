package com.herbalife.exceptionhandlingconsumerapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExceptionHandlingConsumerAppApplicationTests {

    @Test
    void contextLoads() {
    }

}

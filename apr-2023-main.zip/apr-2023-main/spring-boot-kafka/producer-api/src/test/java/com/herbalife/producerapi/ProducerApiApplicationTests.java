package com.herbalife.producerapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProducerApiApplicationTests {

    @Test
    void contextLoads() {
    }

}

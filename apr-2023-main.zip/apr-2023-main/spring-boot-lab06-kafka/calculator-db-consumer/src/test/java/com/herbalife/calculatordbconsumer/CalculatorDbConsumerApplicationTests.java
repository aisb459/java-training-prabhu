package com.herbalife.calculatordbconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalculatorDbConsumerApplicationTests {

    @Test
    void contextLoads() {
    }

}

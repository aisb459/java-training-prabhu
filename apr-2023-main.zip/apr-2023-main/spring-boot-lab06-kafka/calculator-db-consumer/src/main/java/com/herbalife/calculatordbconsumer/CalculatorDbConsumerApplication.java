package com.herbalife.calculatordbconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CalculatorDbConsumerApplication {

    public static void main(String[] args) {
        SpringApplication.run(CalculatorDbConsumerApplication.class, args);
    }

}

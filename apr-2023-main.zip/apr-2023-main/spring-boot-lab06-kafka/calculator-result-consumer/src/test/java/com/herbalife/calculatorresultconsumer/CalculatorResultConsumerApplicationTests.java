package com.herbalife.calculatorresultconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalculatorResultConsumerApplicationTests {

    @Test
    void contextLoads() {
    }

}

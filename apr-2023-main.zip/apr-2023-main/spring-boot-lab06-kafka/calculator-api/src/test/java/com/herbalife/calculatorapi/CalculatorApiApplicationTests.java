package com.herbalife.calculatorapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalculatorApiApplicationTests {

    @Test
    void contextLoads() {
    }

}

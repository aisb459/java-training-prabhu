package com.herbalife.jpawithdatarestapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaWithDataRestApiApplicationTests {

    @Test
    void contextLoads() {
    }

}

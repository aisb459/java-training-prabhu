package com.herbalife.wordplayapi.constants;

public interface Constants {
    String PALINDROME_API_URL = "http://%s:%d/palindrome/%s";
}

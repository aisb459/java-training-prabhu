package com.herbalife.wordplayapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WordPlayApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(WordPlayApiApplication.class, args);
    }

}

package com.herbalife.wordplayapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WordPlayApiApplicationTests {

    @Test
    void contextLoads() {
    }

}

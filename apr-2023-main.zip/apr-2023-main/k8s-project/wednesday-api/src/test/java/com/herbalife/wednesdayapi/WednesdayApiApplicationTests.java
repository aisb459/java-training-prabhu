package com.herbalife.wednesdayapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WednesdayApiApplicationTests {

    @Test
    void contextLoads() {
    }

}

package com.herbalife.wednesdayapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WednesdayApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(WednesdayApiApplication.class, args);
    }

}

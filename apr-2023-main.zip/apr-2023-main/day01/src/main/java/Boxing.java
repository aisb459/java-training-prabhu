public class Boxing {
    public static void main(String[] args) {
        int i = 10;
        Integer iObj = i; //Boxing

        double pi = 3.14;
        Double piObj = pi;

        Integer numObj = 100;
        int num = numObj; //Unboxing

    }
}

public class DataTypes {
    public static void main(String[] args) {
        //primitive and reference types
        //primitive types are stored on the stack
        //reference types are stored on the heap

        int i = 0;
        byte b = 10;
        long num = 10L;
        double pi = 3.14D;
        char ch = 'A';
        boolean bo = true;

        //Wrapper classes
        Integer iObj = 10;
        Double d = 10.34;
        Long l = 2134123L;
        Boolean boolObj = true;
        String str = "Sam";

        String name; //Initialize before use
        //System.out.println(name);
    }
}
